var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","9791f4c0-61c1-4bb7-bee5-492f231c0c2e","13dbef62-e074-44b4-996e-c03a23faefcc","ab572d3b-3e1e-4af3-9ff4-c7406909e0d3","b434edd8-0348-4342-98db-cdc3efa9ab43","68e7ba66-96d3-479b-823c-855e98ae1ec3","de54628b-732a-48b8-a5fd-80b348533fb1"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"Pi8gDIVb3fB8gcU8dFd7xYgLkGBpQ.Lo","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"xX4BF3TOnetVRZCxkd7LrLyUm9dVOdli","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"7btz07YyNk9dZbn74n8v.DYhO7Hd08tR","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"9791f4c0-61c1-4bb7-bee5-492f231c0c2e":{"name":"kidportrait_11_1","sourceUrl":"assets/api/v1/animation-library/gamelab/gRkbtTgvCsmePRu91w1GuwVEnFFFNCR2/category_faces/kidportrait_11.png","frameSize":{"x":264,"y":362},"frameCount":1,"looping":true,"frameDelay":2,"version":"gRkbtTgvCsmePRu91w1GuwVEnFFFNCR2","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":362},"rootRelativePath":"assets/api/v1/animation-library/gamelab/gRkbtTgvCsmePRu91w1GuwVEnFFFNCR2/category_faces/kidportrait_11.png"},"13dbef62-e074-44b4-996e-c03a23faefcc":{"name":"gameplaywacky_04_1","sourceUrl":"assets/api/v1/animation-library/gamelab/6RErheXohDYDqsju4kZuQxK7OYey6QJn/category_germs/gameplaywacky_04.png","frameSize":{"x":391,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"6RErheXohDYDqsju4kZuQxK7OYey6QJn","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":391,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6RErheXohDYDqsju4kZuQxK7OYey6QJn/category_germs/gameplaywacky_04.png"},"ab572d3b-3e1e-4af3-9ff4-c7406909e0d3":{"name":"gameplaywacky_13_1","sourceUrl":"assets/api/v1/animation-library/gamelab/NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN/category_germs/gameplaywacky_13.png","frameSize":{"x":400,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN/category_germs/gameplaywacky_13.png"},"b434edd8-0348-4342-98db-cdc3efa9ab43":{"name":"virus02_01_1","sourceUrl":"assets/api/v1/animation-library/gamelab/AtemlW8XGfmlJ7IlUaLCVSWvZrUul.pl/category_germs/virus02_01.png","frameSize":{"x":278,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"AtemlW8XGfmlJ7IlUaLCVSWvZrUul.pl","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":278,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/AtemlW8XGfmlJ7IlUaLCVSWvZrUul.pl/category_germs/virus02_01.png"},"68e7ba66-96d3-479b-823c-855e98ae1ec3":{"name":"texture_07_1","sourceUrl":"assets/api/v1/animation-library/gamelab/R5Ce80jCzTaJSm89_1XamM0fUQk8ISrS/category_backgrounds/texture_07.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"R5Ce80jCzTaJSm89_1XamM0fUQk8ISrS","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/R5Ce80jCzTaJSm89_1XamM0fUQk8ISrS/category_backgrounds/texture_07.png"},"de54628b-732a-48b8-a5fd-80b348533fb1":{"name":"sun_and_rainbow_1","sourceUrl":"assets/api/v1/animation-library/gamelab/U_B34s7WuMGQBIqtrDWle53mf8DRkN9h/category_backgrounds/sun_and_rainbow.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"U_B34s7WuMGQBIqtrDWle53mf8DRkN9h","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/U_B34s7WuMGQBIqtrDWle53mf8DRkN9h/category_backgrounds/sun_and_rainbow.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b= createSprite(200,200);
 b.setAnimation("sun_and_rainbow_1")
var anna = createSprite(200,345,200,345)
anna.shapeColor="red"

var enemy1 = createSprite(200,250,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var net = createSprite(200,5,200,20)
net.shapeColor="red"

var goal =0;
var death = 0

anna.setAnimation("kidportrait_11_1");
anna.scale=.1;
enemy1.setAnimation("gameplaywacky_04_1");
enemy1.scale=.1;
enemy2.setAnimation("gameplaywacky_13_1");
enemy2.scale=.1;
enemy3.setAnimation("virus02_01_1");
enemy3.scale=.1;

enemy1.setVelocity(-7,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
  
//plano de fundo(arco iris);

createEdgeSprites()




enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown(UP_ARROW)){
  anna.y=anna.y-7
}

if(keyDown(DOWN_ARROW)){
  anna.y=anna.y+7
}

if(keyDown(LEFT_ARROW)){
  anna.x=anna.x-7
}

if(keyDown(RIGHT_ARROW)){
  anna.x=anna.x+7
}

if(anna.isTouching(enemy1)|| anna.isTouching(enemy2)|| anna.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  anna.x=200
  anna.y=350
  death = death+1
}
if(anna.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  anna.x=200
  anna.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Objetivos:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("mortes:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
